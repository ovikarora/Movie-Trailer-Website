Movie Trailer Website
This project is made in python with object oriented programming.

Prerequisites
To run it you just need a working browser.

How to Run:
Download the project "Movie Trailer Website".
Open the fresh_tomatoes.html file.
Click on any movie icon to watch its trailer.